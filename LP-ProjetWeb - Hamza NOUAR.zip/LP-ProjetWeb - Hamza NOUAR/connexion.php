<?php
$cnx=new mysqli("localhost", "root","","gtimage");
if(!$cnx) die ("erreur de connexion à MySQL");
?>